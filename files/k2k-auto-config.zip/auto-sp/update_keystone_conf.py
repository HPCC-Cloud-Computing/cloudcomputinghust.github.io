import sys, fileinput, re

def update_keystone_conf():  
    fh=fileinput.input('/etc/keystone/keystone.conf',inplace=True)  
    for line in fh:  
        repl_auth=line + 'methods = external,password,token,oauth1,saml2' + '\n' + 'saml2 = keystone.auth.plugins.mapped.Mapped'  
        line=re.sub('\[auth\]', repl_auth, line)  
        sys.stdout.write(line) 
    fh.close()  

update_keystone_conf()



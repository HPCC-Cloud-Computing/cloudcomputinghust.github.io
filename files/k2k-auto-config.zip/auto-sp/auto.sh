#!/bin/bash
DEVSTACK=/devstack/
IDP_IP=$(cat /etc/hosts | grep idp | awk '{print $1}')

cd $DEVSTACK
source openrc admin admin
export OS_PROJECT_NAME=admin
export OS_DOMAIN_NAME=Default

cd -

echo "keystone.idp: ${IDP_IP}"
echo "install shibboleth"
sudo apt-get install -y libapache2-mod-shib2 python-lxml
sudo apt-get install libxml2-dev libxslt-dev python-dev -y
sudo pip install --upgrade lxml

echo "run update keystone.conf and apache2 keystone.conf"
sudo python update_keystone_conf.py
sudo python update_apache_conf.py
sudo chown stack.  /etc/keystone/  -Rf


echo "Configuring shibboleth for k2k"
sudo python configure_shibboleth.py $IDP_IP

echo "generate shibboleth key"
sudo shib-keygen -f

echo "make sure that shib2 is enabled"
sudo a2enmod shib2

echo "restart service - shibd and apache2"
sudo service shibd restart
sudo service apache2 restart

echo "run python script to register entities, make mapping and protocols and a bunch of other stuff"
python setup_k2k_sp.py ${IDP_IP}

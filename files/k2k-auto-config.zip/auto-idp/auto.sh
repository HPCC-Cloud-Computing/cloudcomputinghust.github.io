#!/bin/bash
DEVSTACK=/devstack/
IDP_IP=$(cat /etc/hosts | grep idp | awk '{print $1}')
SP_IP=$(cat /etc/hosts | grep sp | awk '{print $1}')
echo "SP IP is ${SP_IP}"
echo "IDP IP is ${IDP_IP}"

cd $DEVSTACK
source openrc admin admin
export OS_PROJECT_NAME=admin
export OS_DOMAIN_NAME=Default

cd -
sudo apt-get install xmlsec1 -y
sudo pip install pysaml2
keystone-manage ssl_setup

python insert_keystone.py $IDP_IP

keystone-manage saml_idp_metadata > /etc/keystone/keystone_idp_metadata.xml

sudo service apache2 restart
python setup_k2k_idp.py
